#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
enum class ${NAME}(val value: Any) {
    ENUMS(""),
    ;

    companion object {
        fun of(value: String): ${NAME} {
            return ${NAME}.values().firstOrNull { it.value == value }
                    ?: throw IllegalArgumentException("illegal value of enums")
        }
    }
}